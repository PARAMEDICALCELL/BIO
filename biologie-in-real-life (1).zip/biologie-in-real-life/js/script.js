/* Biologie in real life - script du site
   Sections : 1. Données  2. Contenu de la page  3. Moteur 3D  4. Modèles 3D  5. Galerie */

/* ==========================================
   1. Données modifiables
   ========================================== */
const PHONE = "212632976735"; // numéro WhatsApp, sans le signe +

// Cours affichés dans la section « Les cours » : [titre, description, filières]
const COURSES = [
  ["Biochimie métabolique", "Glycolyse, cycle de Krebs, chaîne respiratoire, rendement en ATP.", ["Biologie", "Pharmacie", "Médecine"]],
  ["Biologie cellulaire", "Membrane, noyau, organites, cycle cellulaire et transport.", ["Biologie", "Médecine"]],
  ["Physiologie végétale", "Transpiration, nutrition minérale, photosynthèse, voies C3, C4 et CAM.", ["Biologie"]],
  ["Biochimie structurale", "Glucides, lipides, protéines et acides nucléiques.", ["Pharmacie", "Médecine"]],
  ["Neurobiologie", "Neurotransmetteurs, synapses et potentiel d'action.", ["Médecine", "Biologie"]],
  ["Génétique et biologie moléculaire", "Réplication, transcription, traduction et régulation.", ["Biologie", "Pharmacie"]]
];

// Fichiers à télécharger. Exemple : { t: "Résumé glycolyse", d: "Fiche PDF de 2 pages", u: "files/glycolyse.pdf" }
const RESOURCES = [];

/* ==========================================
   2. Contenu de la page
   ========================================== */
// Cartes des cours
const coursesEl = document.getElementById("courses");
COURSES.forEach(([title, desc, tracks]) => {
  const tags = tracks.map((t, i) => `<span class="tag${i % 2 ? " p" : ""}">${t}</span>`).join("");
  coursesEl.insertAdjacentHTML("beforeend",
    `<article class="card"><h3>${title}</h3><p>${desc}</p><div class="tags">${tags}</div></article>`);
});

// Cartes des fichiers
const filesEl = document.getElementById("files");
if (RESOURCES.length) {
  RESOURCES.forEach(r => filesEl.insertAdjacentHTML("beforeend",
    `<article class="card file"><div><h3>${r.t}</h3><p>${r.d}</p></div><a href="${r.u}" download>Télécharger</a></article>`));
} else {
  filesEl.innerHTML = '<article class="card empty"><h3>Les premiers fichiers arrivent bientôt</h3><p>Résumés PDF, fiches de révision et QCM corrigés seront publiés ici.</p></article>';
}

// Liens WhatsApp : chaque élément avec data-wa ouvre une conversation avec ce message
document.querySelectorAll("[data-wa]").forEach(a => {
  a.href = `https://wa.me/${PHONE}?text=${encodeURIComponent(a.dataset.wa)}`;
  a.target = "_blank";
  a.rel = "noopener";
});

/* ==========================================
   3. Moteur 3D (Three.js)
   ========================================== */
const calm = matchMedia("(prefers-reduced-motion:reduce)").matches;

// Crée une scène 3D dans un canvas : rotation automatique, glisser pour tourner
function stage(id, build, tilt) {
  const cv = document.getElementById(id);
  const renderer = new THREE.WebGLRenderer({ canvas: cv, alpha: true, antialias: true });
  const scene = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(45, 1, .1, 50);
  cam.position.z = 5;

  scene.add(new THREE.AmbientLight(0xffffff, .75));
  const light = new THREE.PointLight(0xffffff, .9);
  light.position.set(4, 4, 6);
  scene.add(light);

  const group = new THREE.Group();
  scene.add(group);
  build(group);
  group.rotation.x = tilt || 0;

  const fit = () => {
    const w = cv.clientWidth, h = cv.clientHeight;
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.setSize(w, h, false);
    cam.aspect = w / h;
    cam.updateProjectionMatrix();
  };
  fit();
  addEventListener("resize", fit);

  let drag = false, lastX = 0;
  cv.addEventListener("pointerdown", e => { drag = true; lastX = e.clientX; cv.setPointerCapture(e.pointerId); });
  cv.addEventListener("pointerup", () => drag = false);
  cv.addEventListener("pointermove", e => {
    if (drag) { group.rotation.y += (e.clientX - lastX) * .01; lastX = e.clientX; }
  });

  // On ne dessine que les scènes visibles à l'écran
  let visible = true;
  new IntersectionObserver(e => visible = e[0].isIntersecting).observe(cv);
  (function loop() {
    if (visible) {
      if (!drag && !calm) group.rotation.y += .004;
      renderer.render(scene, cam);
    }
    requestAnimationFrame(loop);
  })();
}

// Outils pour construire les modèles
const M = (color, opts) => new THREE.MeshPhongMaterial(Object.assign({ color, shininess: 80 }, opts));
const V = (x, y, z) => new THREE.Vector3(x, y, z);
const UP = V(0, 1, 0);

// Atome ou sphère
const at = (g, v, r, c) => {
  const m = new THREE.Mesh(new THREE.SphereGeometry(r, 20, 20), M(c));
  m.position.copy(v);
  g.add(m);
};

// Liaison (cylindre) entre deux points
const bond = (g, A, B, c, r) => {
  const d = B.clone().sub(A);
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, d.length(), 10), M(c));
  m.position.copy(A.clone().add(B).multiplyScalar(.5));
  m.quaternion.setFromUnitVectors(UP, d.normalize());
  g.add(m);
};

// Forme translucide (membranes)
const glass = (g, geo, c, opacity, scale) => {
  const m = new THREE.Mesh(geo, M(c, { transparent: true, opacity }));
  if (scale) m.scale.set(...scale);
  g.add(m);
};

/* ==========================================
   4. Modèles 3D
   ========================================== */
// Cellule (scène de l'accueil)
stage("cell", g => {
  glass(g, new THREE.SphereGeometry(1.7, 48, 48), 0xf9a8d4, .28);

  const nucleus = new THREE.Mesh(new THREE.SphereGeometry(.65, 40, 40), M(0x4f8df7));
  nucleus.position.set(-.2, .1, 0);
  g.add(nucleus);

  const nucleolus = new THREE.Mesh(new THREE.SphereGeometry(.22, 24, 24), M(0x1e3a8a));
  nucleolus.position.set(-.05, .25, .5);
  g.add(nucleolus);

  // Mitochondries
  [[.9, -.7, .5], [-1, -.6, .6], [.6, .8, -.8], [-.7, .9, -.7], [.2, -1, -.8]].forEach((p, i) => {
    const m = new THREE.Mesh(new THREE.SphereGeometry(.28, 24, 24), M(0xfb7185));
    m.scale.set(1.7, .8, .8);
    m.position.set(...p);
    m.rotation.z = i;
    g.add(m);
  });

  // Ribosomes
  for (let i = 0; i < 40; i++) {
    const d = new THREE.Mesh(new THREE.SphereGeometry(.045, 8, 8), M(0xa78bfa));
    const a = Math.random() * 6.28, b = Math.acos(2 * Math.random() - 1), R = .9 + Math.random() * .6;
    d.position.set(R * Math.sin(b) * Math.cos(a), R * Math.sin(b) * Math.sin(a), R * Math.cos(b));
    g.add(d);
  }
}, .3);

// Modèles de la galerie
const BUILD = {
  // Double hélice d'ADN
  dna: g => {
    for (let i = 0; i < 26; i++) {
      const y = (i - 13) * .2, a = i * .55;
      const A = V(Math.cos(a) * .8, y, Math.sin(a) * .8), B = V(-A.x, y, -A.z);
      at(g, A, .13, 0xf472b6);
      at(g, B, .13, 0x4f8df7);
      bond(g, A, B, 0xc4b5fd, .035);
    }
    g.scale.setScalar(.7);
  },

  // Mitochondrie : membrane externe, membrane interne et crêtes
  mito: g => {
    glass(g, new THREE.SphereGeometry(1, 40, 40), 0xf9a8d4, .3, [1.9, 1, 1]);
    glass(g, new THREE.SphereGeometry(.85, 32, 32), 0x93c5fd, .35, [1.75, .85, .85]);
    for (let k = -4; k <= 4; k++) {
      const r = .6 - Math.abs(k) * .05;
      const crest = new THREE.Mesh(new THREE.CylinderGeometry(r, r, .06, 24), M(k % 2 ? 0x4f8df7 : 0xf472b6));
      crest.rotation.z = Math.PI / 2;
      crest.position.x = k * .3;
      g.add(crest);
    }
    g.scale.setScalar(.9);
  },

  // Bicouche lipidique : têtes hydrophiles et queues hydrophobes
  bilayer: g => {
    for (let x = -3; x <= 3; x++) {
      for (let z = -3; z <= 3; z++) {
        [1, -1].forEach(s => {
          const px = x * .42 + (s > 0 ? 0 : .2), pz = z * .42;
          at(g, V(px, s * .75, pz), .14, s > 0 ? 0xf472b6 : 0x4f8df7);
          bond(g, V(px, s * .7, pz), V(px, s * .1, pz), 0xc4b5fd, .03);
        });
      }
    }
  },

  // Glucose : cycle à six atomes avec ses groupements
  glucose: g => {
    const P = i => V(Math.cos(i * 1.047), 0, Math.sin(i * 1.047));
    for (let i = 0; i < 6; i++) {
      at(g, P(i), .2, i ? 0x3b4a7a : 0xef4444); // le premier atome est l'oxygène du cycle
      bond(g, P(i), P((i + 1) % 6), 0x94a3b8, .05);
      if (i) {
        const s = i % 2 ? 1 : -1;
        const O = P(i).multiplyScalar(1.15).add(V(0, s * .75, 0));
        bond(g, P(i), O, 0x94a3b8, .04);
        at(g, O, .15, 0xef4444);
        at(g, O.clone().add(V(.2, s * .3, .1)), .09, 0xf8fafc);
      }
    }
    const C = P(5).multiplyScalar(1.3).add(V(0, .9, 0));
    bond(g, P(5), C, 0x94a3b8, .05);
    at(g, C, .2, 0x3b4a7a);
    at(g, C.clone().add(V(0, .6, .3)), .15, 0xef4444);
    g.scale.setScalar(1.05);
  },

  // Chloroplaste : enveloppe et grana (piles de thylakoïdes)
  chloro: g => {
    glass(g, new THREE.SphereGeometry(1, 40, 40), 0x93c5fd, .28, [1.9, 1.1, 1.1]);
    [[-.8, .15, .1], [0, -.2, .25], [.75, .2, -.15], [-.2, .25, -.4]].forEach(p => {
      for (let k = 0; k < 6; k++) {
        const disc = new THREE.Mesh(new THREE.CylinderGeometry(.32, .32, .07, 24), M(k % 2 ? 0x4f8df7 : 0x60a5fa));
        disc.position.set(p[0], p[1] + k * .11 - .28, p[2]);
        g.add(disc);
      }
    });
    at(g, V(.2, .7, .3), .08, 0xf472b6);
    at(g, V(-1.2, -.4, .2), .08, 0xf472b6);
    at(g, V(1.3, -.3, .1), .08, 0xf472b6);
    g.scale.setScalar(.9);
  },

  // Hélice alpha d'une protéine
  helix: g => {
    let prev;
    for (let i = 0; i < 60; i++) {
      const a = i * .62;
      const v = V(Math.cos(a) * .7, (i - 30) * .075, Math.sin(a) * .7);
      const c = new THREE.Color().setHSL(.93 - i / 60 * .35, .85, .65).getHex();
      at(g, v, .1, c);
      if (prev) bond(g, prev, v, c, .045);
      prev = v;
    }
    g.scale.setScalar(.85);
  }
};

/* ==========================================
   5. Galerie : titre, description et modèle
   ========================================== */
const MODELS = [
  ["dna", "Double hélice d'ADN", "Deux brins complémentaires reliés par les paires de bases."],
  ["mito", "Mitochondrie", "Membranes et crêtes où se déroulent la chaîne respiratoire et la synthèse d'ATP."],
  ["bilayer", "Bicouche lipidique", "Têtes hydrophiles à l'extérieur, queues hydrophobes au centre de la membrane."],
  ["glucose", "Molécule de glucose", "Le cycle à six atomes, point de départ de la glycolyse."],
  ["chloro", "Chloroplaste", "Les grana empilés sont le siège des réactions photochimiques."],
  ["helix", "Hélice alpha", "Structure secondaire d'une protéine, stabilisée par des liaisons hydrogène."]
];

const gallery = document.getElementById("gallery");
MODELS.forEach(([key, title, desc]) => gallery.insertAdjacentHTML("beforeend",
  `<figure class="card"><div class="stage"><canvas id="m-${key}" role="img" aria-label="Modèle 3D : ${title}"></canvas></div><figcaption><h3>${title}</h3><p>${desc}</p></figcaption></figure>`));
MODELS.forEach(([key]) => stage("m-" + key, BUILD[key], .35));
